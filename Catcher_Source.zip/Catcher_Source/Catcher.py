import  random
import pygame

pygame.init()
FPS = 60
LARGHEZZA = 800
ALTEZZA = 700
SCHERMO = pygame.display.set_mode((LARGHEZZA, ALTEZZA))
pygame.display.set_caption("Catcher")
Enemy = pygame.image.load("Sprites/Enemy.png")
Player = pygame.image.load("Sprites/Player.png")
Logo = pygame.image.load("Sprites/Logo.png")
Word = pygame.image.load("Sprites/Word.png")
pygame.mixer.music.load('Musics/Background_music.mp3')
pygame.display.set_icon(Logo)

Word = pygame.transform.scale(Word, (400,350))
Word_Flipped = pygame.transform.flip(Word, True, False)
Player = pygame.transform.scale(Player, (40,80))
Enemy = pygame.transform.scale(Enemy, (40,80))
sprite_rect = Enemy.get_rect()

Player_x = random.randint(0, 800)
Player_y = random.randint(0,700)
Enemy_x = random.randint(0, 800)
Enemy_y = random.randint(0,700)
Player_speed = 2
Enemy_speed = 2

sprite_rect.x = random.randint(0, LARGHEZZA - sprite_rect.width)
sprite_rect.y = random.randint(0, ALTEZZA - sprite_rect.height)

pygame.mixer.music.play(-1)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    mouse_x, mouse_y = pygame.mouse.get_pos()
    direction_x = mouse_x - sprite_rect.x
    direction_y = mouse_y - sprite_rect.y
    length = (direction_x ** 2 + direction_y ** 2) ** 0.5
    if length != 0:
        direction_x /= length
        direction_y /= length

    sprite_rect.x += int(direction_x * Player_speed)
    sprite_rect.y += int(direction_y * Player_speed)

    player_rect = pygame.Rect(Player_x, Player_y, Player.get_width(), Player.get_height())
    enemy_rect = pygame.Rect(Enemy_x, Enemy_y, Enemy.get_width(), Enemy.get_height())

    keys = pygame.key.get_pressed()
    if keys[pygame.K_a]:
        Player_x -= Player_speed
    if keys[pygame.K_d]:
        Player_x += Player_speed
    if keys[pygame.K_w]:
        Player_y -= Player_speed
    if keys[pygame.K_s]:
        Player_y += Player_speed

    sprite_rect.x = max(0, min(sprite_rect.x, LARGHEZZA - sprite_rect.width))
    sprite_rect.y = max(0, min(sprite_rect.y, ALTEZZA - sprite_rect.height))

    if Player_x <= 0:
        Player_x = 0
    elif Player_x >= 760:
        Player_x = 760
    if Player_y <= -3:
        Player_y = -3
    elif Player_y >= 620:
        Player_y = 620

    if Enemy_x <= 0:
        Enemy_x = 0
    elif Enemy_x >= 760:
        Enemy_x = 760
    if Enemy_y <= -3:
        Enemy_y = -3
    elif Enemy_y >= 620:
        Enemy_y = 620

    if keys[pygame.K_LEFT]:
        Enemy_x -= Enemy_speed

    if keys[pygame.K_RIGHT]:
        Enemy_x += Enemy_speed
    if keys[pygame.K_UP]:
        Enemy_y -= Enemy_speed
    if keys[pygame.K_DOWN]:
        Enemy_y += Enemy_speed

    if player_rect.colliderect(enemy_rect):
        running = False

    SCHERMO.blit(Word, (0, 0))
    SCHERMO.blit(Word_Flipped, (400, 0))
    SCHERMO.blit(Word, (400, 350))
    SCHERMO.blit(Word_Flipped, (0, 350))
    SCHERMO.blit(Player, (Player_x, Player_y))
    SCHERMO.blit(Enemy, (Enemy_x, Enemy_y))

    pygame.display.update()
